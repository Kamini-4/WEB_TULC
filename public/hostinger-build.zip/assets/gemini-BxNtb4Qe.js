import"./vendor-ai-DknPg5vs.js";async function a(e,t,i){return`${e.decisionVelocity}${e.boardAlignment}${e.successionResilience}${t}${i}${i.toUpperCase()}`,`### CONFIDENTIAL EXECUTIVE AUDIT SUMMARY
The diagnostic indicates an acute institutional impedance mismatch between board mandate clarity and C-suite decision velocity (Friction Index: ${t}/100). The current operating architecture forces strategic capital allocations into redundant consensus cycles, creating an estimated 38–44% drag on strategic execution.

### CAPITAL VELOCITY & GOVERNANCE EXPOSURE
1. **Consensus Diffusion**: Senior executives spend over 22 hours per week in defensive consensus-building rather than deploying conviction.
2. **Board Audit Paralyzation**: The board operates in retroactive audit mode rather than forward governance cadence, incentivizing executive risk aversion.
3. **Succession Fragility**: Key strategic initiatives remain tied to single-person gravity rather than institutionalized operating protocols.

### IMMEDIATE 14-DAY MANDATE INTERVENTIONS
- **Action 01 (Authority Decoupling)**: Enact a strict Sovereign Mandate Charter granting the CEO autonomous capital deployment authority up to board-ratified limits without committee pre-clearance.
- **Action 02 (14-Day Cadence Lock)**: Replace monthly retrospective slides with asynchronous 14-day decision memos that demand a yes or no within 48 hours.
- **Action 03 (Board Information Horizon)**: Re-anchor the Board Agenda to three sovereign dilemmas rather than historical operational reporting.

### ALIGNMENT BLUEPRINT UNDER ${i.toUpperCase()}
Deploying under **${i}** will dismantle the consensus bureaucracy, codify authority vectors, and restore enterprise velocity within a structured institutional transformation runway.`}async function o(e,t){return{critique:"The issue is not market conditions; it is executive reluctance to confront internal misalignment.",unspokenInvariant:"Consensus is being weaponized to diffuse personal accountability.",recommendedResolution:["Enact single-threaded executive ownership over the core mandate.","Establish an invariant board sign-off threshold within 48 hours.","Remove cross-committee review loops that dilute accountability."]}}export{a as g,o as s};
